def test_signup(client):
    response = client.post("/signup", params={
        "email": "teste@example.com",
        "password": "123456"
    })
    assert response.status_code == 200
